public class Assistente extends Funcionario {
    private int nMatricula;

    public int getnMatricula() {
        return nMatricula;
    }
    
    public void exibeDados(){
    }
}
