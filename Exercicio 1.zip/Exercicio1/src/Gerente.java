public class Gerente {
    
}
