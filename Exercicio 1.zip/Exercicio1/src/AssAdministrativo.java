public class AssAdministrativo {
    private char turno;
    private int adNoturno;
}

