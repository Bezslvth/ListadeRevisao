public class Funcionario {
    
}
