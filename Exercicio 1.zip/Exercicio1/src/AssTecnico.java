public class AssTecnico {
    private int bsalarial;
}
