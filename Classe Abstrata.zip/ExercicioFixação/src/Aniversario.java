
import javax.swing.JOptionPane;

public class Aniversario extends CartaoWeb {
    private String remetente2;
    
    public String getRemetente2() {
        return remetente2;
    }

    public void setRemetente2(String remetente) {
        this.remetente2 = remetente2;
    }
    public Aniversario(){
    }

    @Override
    public void retornarMensagem(String remetente) {
        JOptionPane.showMessageDialog(null, "Feliz Aniversário, "+remetente2);
    }
}
