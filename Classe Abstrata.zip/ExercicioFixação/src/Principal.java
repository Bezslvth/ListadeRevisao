
import java.lang.reflect.Array;

public class Principal {
    private int i;
    public static void main (String []args){
        
        double[] CartaoWeb = new double[3];
  
        
    }
}
