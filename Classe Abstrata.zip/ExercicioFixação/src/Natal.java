
import javax.swing.JOptionPane;

public class Natal extends CartaoWeb {
    private String remetente1;
    
    public String getRemetente1() {
        return remetente1;
    }

    public void setRemetente1(String remetente) {
        this.remetente1 = remetente1;
    }
    
    public Natal(){
    }

    @Override
    public void retornarMensagem(String remetente) {
        JOptionPane.showMessageDialog(null, "Feliz Natal, "+remetente1);
    }
}
