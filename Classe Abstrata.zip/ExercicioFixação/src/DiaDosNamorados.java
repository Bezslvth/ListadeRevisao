
import javax.swing.JOptionPane;

public class DiaDosNamorados extends CartaoWeb {
    private String remetente;
    
    public String getRemetente() {
        return remetente;
    }

    public void setRemetente(String remetente) {
        this.remetente = remetente;
    }
    public DiaDosNamorados(){
    }

    @Override
    public void retornarMensagem(String remetente) {
        JOptionPane.showMessageDialog(null, "Querida, " + remetente + ", Feliz dia dos Namorados!");
    }
}
