public class Ingresso {
    private double valor;
    
    public double imprimeValor(){
        return valor;
    }
}
