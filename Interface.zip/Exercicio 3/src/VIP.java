public class VIP extends Ingresso{
    private double adc;
    
    public double imprimeValor(double valor, double adc){
        return valor + adc;
    }
}
